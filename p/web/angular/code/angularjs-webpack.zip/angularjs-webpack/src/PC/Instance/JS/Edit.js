﻿import "../CSS/Edit.less";

(function () {
    "use strict";
    //@ sourceURL=Edit.js

    //  编辑页面
    app.register.controller("Module1_Instance_Edit_Controller", function ($scope, $state) {

        $scope.pageInfo = "自我介绍：这里是编辑页面。";
        $scope.guid = du.utils.getGUID();

        $scope.parentObj = {
            module1Id: $state.params?.module1Id,
            context: $state.params?.Module1EditContext,
            extend: $state.params?.Module1EditExtend,
        };
    });
})();
