﻿import "../CSS/List.less";

(function () {
    "use strict";
    //@ sourceURL=List.js

    //  新建页面
    app.register.controller("Module1_Instance_List_Controller", function ($scope, $state) {

        $scope.pageInfo = "自我介绍：这里是列表页面。";
        $scope.guid = du.utils.getGUID();

        $scope.context = {
            info: "我是通过$scope的方式传递的"
        };

        if (!$state.get("Module1.Add")) {
            app.register.state("Module1.Add", {
                url: "/M1Add",
                templateUrl: "/BaseModule/Module1/PC/Instance/Add.html",
                // params: {
                //     context: null,
                //     extend: null
                // },
                params: {
                    Module1AddContext: null,
                    Module1AddExtend: null
                },
                resolve: {
                    loadJSAhead: app.loadJS(["/BaseModule/Module1/PC/Instance/JS/Add.js"])
                }
            });
        }

        if (!$state.get("Module1.Edit")) {
            app.register.state("Module1.Edit", {
                url: "/M1Edit/:module1Id",
                templateUrl: "/BaseModule/Module1/PC/Instance/Edit.html",
                // params: {
                //     context: null,
                //     extend: null
                // },
                params: {
                    Module1EditContext: null,
                    Module1EditExtend: null
                },
                resolve: {
                    loadJSAhead: app.loadJS(["/BaseModule/Module1/PC/Instance/JS/Edit.js"])
                }
            });
        }
        $scope.uiViewIsShow = false;

        $scope.openAdd = function () {
            loadJSByScriptTag(["/BaseModule/Module1/PC/Instance/JS/Module-Extend.js"]).then(function () {
                //$state.go("Module1.Add", { context: { info: "我是通过$scope的方式传递的", p1: "a", p2: "a" }, extend: { other: "" } });
                $state.go("Module1.Add", { Module1AddContext: { info: "我是通过$scope的方式传递的", p1: "a", p2: "a" }, Module1AddExtend: { other: "" } });
                $scope.uiViewIsShow = true;
                // $scope.$digest();
                // $scope.$apply();
            });
        }
        $scope.openEdit = function () {
            loadJSByScriptTag(["/BaseModule/Module1/PC/Instance/JS/Module-Extend.js"]).then(() => {
                $state.go("Module1.Edit", { module1Id: "999", Module1EditContext: { p1: "a", p2: "a" }, Module1EditExtend: { other: "" } });
                $scope.uiViewIsShow = true;
            });
        }
    });
})();
