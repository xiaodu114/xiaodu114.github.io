import "../CSS/Design.less";

(function () {
    "use strict";
    //@ sourceURL=Design.js

    //  新建页面
    app.register.controller("Module1_Design_Controller", function ($scope) {

        $scope.pageInfo = "自我介绍：这里是设计时页面。";

        //  模板字符串``相关
        console.log(`模板字符串-反引号=>现在时间：${new Date()}`);

        //  解构赋值相关
        let { log } = console;
        const PI = 3.14;
        log("解构console之log方法，之后输入常量π的近似值：" + PI);

        let contextInfo = {
            readonly: false,
            userInfo: {
                name: "ddz001",
                pwd: "",
                tokenId: "666"
            },
            p1: "888",
            fn1() {
                console.log("contextInfo.fn1");
            }
        };
        let { readonly: isReadOnly, p1 } = contextInfo;
        console.log("对象解构赋值之是否只读：" + isReadOnly);
        console.log("对象解构赋值之p1：" + p1);

        let [arrIndex0 = 10, arrIndex1, arrIndex2, arrIndex3 = 4] = [0, [1, 2], 3];
        console.log("数值解构赋值之第一个：" + arrIndex0);
        console.log("数值解构赋值之第二个：" + arrIndex1);
        console.log("数值解构赋值之第三个：" + arrIndex2);
        console.log("数值解构赋值之第四个：" + arrIndex3);

        //  类(Class)相关
        class Person {
            constructor(name) {
                this.name = name;
                this.gender = "";
                this.birthday = "";
                this.idCard = "";
            }

            sayName() {
                return this.name;
            }
        }
        let person1 = new Person("ddz001");
        console.log(person1);

        //  async、await 关键字相关
        async function promiseFn1() {
            return "async、await相关：该方法没有返回Promise，而是在方法前添加async";
        }
        let retPromiseFn1 = promiseFn1();
        console.log("async、await相关：" + Object.prototype.toString.call(retPromiseFn1));

        async function promiseFn2() {
            // let isTrue = await Promise.resolve(true);
            let isTrue = await true;
            let retPromiseFn1 = await promiseFn1();
            console.log("async、await相关：" + isTrue);
            console.log("async、await相关：" + retPromiseFn1);
        }
        promiseFn2();

        //**************************************************************************************************************/

        console.log("数组实例方法includes：" + [1, 2, 3].includes("1"));
        console.log("数组实例方法includes：" + [1, 2, 3].includes(3));
        let arrFromStr = Array.from("利用Array.from将字符串转成数组！");
        console.log(arrFromStr);

        let set1 = new Set([1, 6, 6, 6, 8, 8, 8, 9]);
        console.log(set1);

        Promise.resolve(999).then(x => {
            console.log("Promise返回值：" + x);
        });

    });
})();
