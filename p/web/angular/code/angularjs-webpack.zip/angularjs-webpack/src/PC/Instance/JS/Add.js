﻿import "../CSS/Add.less";

(function () {
    "use strict";
    //@ sourceURL=Add.js

    //  新建页面
    app.register.controller("Module1_Instance_Add_Controller", function ($scope, $state) {

        $scope.pageInfo = "自我介绍：这里是新建页面。";
        $scope.guid = du.utils.getGUID();

        $scope.parentObj = {
            context: $state.params?.Module1AddContext,
            extend: $state.params?.Module1AddExtend,
        };
    });
})();
