(function () {
    "use strict";
    //@ sourceURL=Module-Extend.js

    var module1Extend = angular.module("business-module1-extend", []);

    module1Extend.directive('myForm', function ($timeout) {
        return {
            restrict: "EA",
            replace: true,
            templateUrl: '/BaseModule/Module1/PC/Instance/Template/MyForm.html',
            scope: {
                config: "="
            },
            link: function (scope, el, attrs) {

            }
        }
    });

    if (window.app && app.useModule) {
        app.useModule('business-module1-extend');
    }
})();