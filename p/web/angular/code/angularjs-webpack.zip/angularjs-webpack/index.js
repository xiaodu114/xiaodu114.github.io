//  https://github.com/ded/script.js
function loadJSByScriptTag(urls) {
    return new Promise((resolve, reject) => {
        if (!(Array.isArray(urls) && urls.length)) {
            resolve();
            return;
        }
        Promise.all(urls.map((url) => {
            return new Promise((resolveCh, rejectCh) => {
                let scriptEle = document.createElement("script");
                scriptEle.src = url;
                scriptEle.addEventListener("load", () => {
                    resolveCh();
                });
                document.head.appendChild(scriptEle);
            });
        })).then(() => {
            resolve();
        });
    });
}

window.loadJSByScriptTag = loadJSByScriptTag;

window.app = angular.module('myApp', ['ui.router']);

app.config(function ($locationProvider, $controllerProvider, $compileProvider, $filterProvider, $provide, $stateProvider) {
    //  Uncaught Error: [$location:nobase] $location in HTML5 mode requires a <base> tag to be present!
    //  需要在 head 中添加 <base href="/">
    $locationProvider.html5Mode(true);
    app.useModule = function (name) {
        //判断app中如果已加载该模块不在加载
        if (app.requires.includes(name)) {
            return app;
        }
        var module = null
        try {
            module = angular.module(name);
        } catch (e) { }
        if (module != null) {
            app.requires.push(name);
        }
        if (Array.isArray(module.requires) && module.requires.length) {
            [].forEach.call(module.requires, (item) => {
                if (app.requires.includes(item)) return;
                app.useModule(item);
            });
        }
        angular.forEach(module._invokeQueue, function (args) {
            var provider;
            switch (args[0]) {
                case "$controllerProvider":
                    provider = $controllerProvider;
                    break;
                case "$compileProvider":
                    provider = $compileProvider;
                    break;
                case "$filterProvider":
                    provider = $filterProvider;
                    break;
                case "$provide":
                    provider = $provide;
                    break;
                default:
                    provider = $injector.get(args[0])
                    break;
            }
            provider[args[1]].apply(provider, args[2]);
        });
        angular.forEach(module._configBlocks, function (args) {
            var provider = $injector.get(args[0]);
            provider[args[1]].apply(provider, args[2]);
        });
        angular.forEach(module._runBlocks, function (args) {
            if (angular.bootstrapResult) {
                angular.bootstrapResult.invoke(args);
            } else {
                $injector.invoke(args);
            }
        });
        return app;
    };
    app.register = {
        state: $stateProvider.state,
        controller: $controllerProvider.register
    };

    //  注册路由  
    $stateProvider.state("Home", {
        url: "/",
        templateUrl: "app-workbench-module"
    });
    $stateProvider.state("About", {
        url: "/About",
        templateUrl: "app-about-module"
    });
    $stateProvider.state("NotFound", {
        url: "/404",
        templateUrl: "app-404-module",
        params: {
            context: null,
            extend: null
        }
    });
});

app.loadJS = function (urls) {
    return function ($q, $rootScope) {
        var def = $q.defer();
        loadJSByScriptTag(urls).then(function () {
            $rootScope.$apply(function () {
                def.resolve();
            });
        });
        return def.promise;
    };
}

app.controller("MyAppController", function ($scope, $state, $timeout) {
    //  注册路由
    app.register.state("Module1", {
        url: "/Module1",
        templateUrl: "/BaseModule/Module1/PC/Instance/List.html",
        params: {
            context: null,
            extend: null
        },
        resolve: {
            loadJSAhead: app.loadJS(["/BaseModule/Module1/PC/Instance/JS/List.js"])
        }
    });
    app.register.state("Module1-Design", {
        url: "/Module1-Design",
        templateUrl: "/BaseModule/Module1/PC/Design/Design.html",
        params: {
            context: null,
            extend: null
        },
        resolve: {
            loadJSAhead: app.loadJS(["/BaseModule/Module1/PC/Design/JS/Design.js"])
        }
    });

    $scope.header = {
        msg: "导航区域：",
        tabs: [{
            code: "Module1",
            text: "模块1-运行时",
            params: {
                context: null,
                extend: null
            }
        }, {
            code: "Module1-Design",
            text: "模块1-设计时",
            params: {
                context: null,
                extend: null
            }
        }, {
            code: "Module2",
            text: "模块2（未注册路由）",
        }],
        tabClick(tab, index, event) {
            if ($state.get(tab.code)) {
                $state.go(tab.code, tab.params);
            }
            else {
                $state.go("NotFound", {
                    context: {
                        stateName: tab.code
                    },
                    extend: {}
                });
            }
        },
        otherGo(code) {
            switch (code) {
                case "Home": {
                    $state.go(code);
                    break;
                }
                case "About": {
                    $state.go(code);
                    break;
                }
                default: {
                    $state.go("NotFound", {
                        context: {
                            stateName: code
                        },
                        p1: "888"
                    });
                    break;
                }
            }
        }
    };

});
app.controller("Level1_Workbench_Controller", function ($scope) {
    $scope.msg = "我是工作台页面";
});
app.controller("Level1_About_Controller", function ($scope) {
    $scope.msg = "我是关于页面";
});
app.controller("Level1_404_Controller", function ($scope, $state) {
    $scope.msg = "我是404页面";
    $scope.goToStateName = $state.params?.context?.stateName;
});
