export default {
    loadedFormCofig() {
        return new Promise((resolve, reject) => {
            resolve({});
        });
    }
}