// yarn add vue@next
// yarn add @vue/compiler-sfc css-loader html-loader html-webpack-plugin less less-loader style-loader vue-loader@next webpack webpack-cli -D

const path = require('path');
const webpack = require('webpack');
const HtmlWebPack = require('html-webpack-plugin');
const {
    VueLoaderPlugin
} = require('vue-loader');

let multiPageConfig = [{
    entry: {
        sourcePath: "./src/module1/js/index.js",
        // entry.key中以'/'分割，最后一项是文件的名称，前面的都是目录
        targetPath: "module1/js/index"
    },
    htmlWebPack: {
        sourcePath: './src/module1/index.html',
        targetPath: 'module1/index.html'
    }
}, {
    entry: {
        sourcePath: "./src/module2/js/index.js",
        targetPath: "module2/js/index"
    },
    htmlWebPack: {
        sourcePath: './src/module2/index.html',
        targetPath: 'module2/index.html'
    }
}];

let tempModuleExportsObj = {
    mode: 'development', // production | development
    devtool: "source-map",
    entry: {},
    output: {
        filename: '[name].js',
        path: path.resolve(__dirname, './www'),
        //publicPath: '/'
        //  为了可以在github上可以浏览，这里做下面的修改
        publicPath: '/vue3/www/'
    },
    module: {
        rules: [{
                test: /\.vue$/,
                use: ['vue-loader']
            }, {
                test: /\.less$/,
                use: ['style-loader', 'css-loader', 'less-loader']
            }, {
                test: /\.html$/,
                use: ['html-loader']
            },
            {
                test: /\.(jpg|jpeg|png|gif|svg|eot|svg|ttf|woff|woff2)$/,
                type: 'asset/resource',
                generator: {
                    filename(a, b) {
                        // a.asdf => "src/common/images/logo.png"
                        return path.relative(path.join(__dirname, "src"), path.resolve(a.filename)).split(path.sep).join("/");
                    }
                }
            }
        ]
    },
    resolve: {
        alias: {
            //  [Vue warn]: Component provided template option but runtime compilation is not supported in this build of Vue. Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js". 
            'vue': 'vue/dist/vue.esm-bundler.js'
        }
    },
    plugins: [
        //  Feature flags __VUE_OPTIONS_API__, __VUE_PROD_DEVTOOLS__ are not explicitly defined. You are running the esm-bundler build of Vue, which expects these compile-time feature flags to be globally injected via the bundler config in order to get better tree-shaking in the production bundle.
        new webpack.DefinePlugin({
            __VUE_OPTIONS_API__: true,
            __VUE_PROD_DEVTOOLS__: false,
        }),
        new VueLoaderPlugin()
    ]
};
multiPageConfig.forEach(singlePage => {
    let tempEntryObj = {};
    tempEntryObj[singlePage.entry.targetPath] = singlePage.entry.sourcePath;
    Object.assign(tempModuleExportsObj.entry, tempEntryObj);
    let tempHtmlWebPackOption = {
        inject: true,
        hash: true, //开启hash  ?[hash]
        chunks: [singlePage.entry.targetPath], //页面要引入的包
    };
    Object.assign(tempHtmlWebPackOption, {
        template: singlePage.htmlWebPack.sourcePath,
        filename: singlePage.htmlWebPack.targetPath
    });
    tempModuleExportsObj.plugins.push(new HtmlWebPack(tempHtmlWebPackOption));
});
module.exports = tempModuleExportsObj;