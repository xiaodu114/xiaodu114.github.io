import * as Vue from "vue";
import DisplayText from '../../common/component/DisplayText.vue';
Vue.createApp({
    data() {
        return {
            msg: "Hi，这里是 Vue3 + webpack 多入口 示例项目 模块1 入口页面",
            displayText: "再说一遍，这里是 模块1 入口页面",
            displayTextStyle: {
                fontWeight: "bold"
            }
        }
    },
    components: {
        DisplayText
    }
}).mount('#vue3Module1Entry');