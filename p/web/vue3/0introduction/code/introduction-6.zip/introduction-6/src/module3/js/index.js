import * as utils from '../../common/js/utils';

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("array-from-1").innerHTML = Array.from("利用Array.from将字符串转成数组！");
    document.getElementById("array-from-2").innerHTML = JSON.stringify(Array.from({
        0: null,
        1: undefined,
        2: true,
        3: 666,
        4: "我是字符串",
        5: Symbol("key1"),
        6: {
            key1: 1,
            key2: 2
        },
        7: ["a", "b", "c"],
        8: function () {},
        length: 9,
    }));
    document.getElementById("array-from-3").innerHTML = Array.from({
        1: "b",
        3: "d",
        length: 6
    });

    Promise.resolve("Promise的返回结果：888").then((ret) => {
        document.getElementById("promise-1").innerHTML = ret;
    });
    document.getElementById("guid1").innerHTML = "一个GUID：" + utils.getGUID();
});