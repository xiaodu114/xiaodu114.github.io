/*! utils.js  业务无关通用方法 */
/**
 * 获取一个GUID
 * 例子：getGUID();=>'AEFC9ABC-1396-494B-AB96-C35CA3C9F92F'
 * @returns {string} 返回一个GUID
 */
export const getGUID = function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        let r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16).toUpperCase();
    });
}