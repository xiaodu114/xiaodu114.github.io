import * as Vue from "vue";
Vue.createApp({
    data() {
        return {
            msg: "Hi，这里是 Vue3 + webpack 多入口 示例项目 模块2 入口页面"
        }
    }
}).mount('#vue3Module2Entry');