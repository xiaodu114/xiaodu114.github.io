import * as Vue from "vue";
Vue.createApp({
    data() {
        return {
            msg: "Hi，这里是 Vue3 + webpack 多入口 示例项目 模块1 入口页面"
        }
    }
}).mount('#vue3Module1Entry');