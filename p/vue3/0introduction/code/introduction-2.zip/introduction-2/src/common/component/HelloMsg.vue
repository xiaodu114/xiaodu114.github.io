<template>
  <div class="hello-msg-container">
    <p class="msg-text">Hello {{msg}}</p>
  </div>
</template>
<script>
export default {
  props: {
    msg: {
      type: String,
      default() {
        return "Vue 3";
      },
    },
  },
};
</script>
<style lang="less">
.hello-msg-container {
  border: 1px solid #3cb878;
  padding: 15px;
  margin-bottom: 10px;
  > .msg-text {
    font-size: 18px;
    font-weight: bold;
  }
}
</style>