<template>
  <div>
    <p>Hello {{msg}}</p>
  </div>
</template>
<script>
export default {
  props: {
    msg: {
      type: String,
      default() {
        return "Vue 3";
      },
    },
  },
};
</script>