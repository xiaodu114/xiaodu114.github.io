import * as Vue from "vue";
import HelloMsg from '../../common/component/HelloMsg.vue';
Vue.createApp({
    data() {
        return {
            msg: "Hi，这里是 Vue3 + webpack 多入口 示例项目 模块1 入口页面",
            helloMsg: "我是 模块1 入口页面"
        }
    },
    components: {
        HelloMsg
    }
}).mount('#vue3Module1Entry');