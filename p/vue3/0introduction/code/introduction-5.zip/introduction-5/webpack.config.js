// yarn add vue@next
//  下面的这个没有添加ES6+转ES5依赖,你可以和安装之后做一下对比
// yarn add @vue/compiler-sfc css-loader html-loader html-webpack-plugin less less-loader style-loader vue-loader@next webpack webpack-cli -D
//  ES6+转ES5，第一种实现方式新增的依赖：@babel/core @babel/preset-env babel-loader core-js regenerator-runtime
// yarn add @babel/core @babel/preset-env @vue/compiler-sfc babel-loader core-js css-loader html-loader html-webpack-plugin less less-loader regenerator-runtime style-loader vue-loader@next webpack webpack-cli -D
//  ES6+转ES5，第二种实现方式新增的依赖：@babel/core @babel/plugin-transform-runtime @babel/preset-env @babel/runtime @babel/runtime-corejs3 babel-loader
// yarn add @babel/core @babel/plugin-transform-runtime @babel/preset-env @babel/runtime @babel/runtime-corejs3 @vue/compiler-sfc babel-loader css-loader html-loader html-webpack-plugin less less-loader style-loader vue-loader@next webpack webpack-cli -D 

const path = require('path');
const webpack = require('webpack');
const HtmlWebPack = require('html-webpack-plugin');
const {
    VueLoaderPlugin
} = require('vue-loader');

let multiPageConfig = [{
    entry: {
        sourcePath: "./src/module1/js/index.js",
        // entry.key中以'/'分割，最后一项是文件的名称，前面的都是目录
        targetPath: "module1/js/index"
    },
    htmlWebPack: {
        sourcePath: './src/module1/index.html',
        targetPath: 'module1/index.html'
    }
}, {
    entry: {
        sourcePath: "./src/module2/js/index.js",
        targetPath: "module2/js/index"
    },
    htmlWebPack: {
        sourcePath: './src/module2/index.html',
        targetPath: 'module2/index.html'
    }
}, {
    entry: {
        sourcePath: "./src/module3/js/index.js",
        targetPath: "module3/js/index"
    },
    htmlWebPack: {
        sourcePath: './src/module3/index.html',
        targetPath: 'module3/index.html'
    }
}];

let tempModuleExportsObj = {
    mode: 'development', // production | development
    devtool: "source-map",
    target: ['web', 'es5'],
    entry: {},
    output: {
        filename: '[name].js',
        path: path.resolve(__dirname, './www'),
        //publicPath: '/'
        //  为了可以在github上可以浏览，这里做下面的修改
        publicPath: '/vue3/www/'
    },
    module: {
        rules: [{
            test: /\.vue$/,
            use: ['vue-loader']
        }, {
            test: /\.html$/,
            loader: 'html-loader',
            options: {
                sources: {
                    // // 第一版使用的方式，但是不太好，不能过滤标签
                    // urlFilter: (attrName, value, absolutePath) => {
                    //     // attrName => "src"
                    //     // value => "/p/_/js/main.js"
                    //     // absolutePath  => "F:\……\src\module3\index.html"
                    //     if (attrName === "src" && value.startsWith("/")) {
                    //         return false;
                    //     }
                    //     return true;
                    // },
                    list: [
                        "...",
                        {
                            tag: "script",
                            attribute: "src",
                            type: "src",
                            filter: (tagName, attrName, kvs, absolutePath) => {
                                // tagName => "script"
                                // attrName => "src"
                                // kvs => [{"name":"src","value":"/p/_/js/main.js"}]
                                // absolutePath => "F:\……\src\module3\index.html"
                                let srcKV = null;
                                if (tagName === "script" &&
                                    attrName === "src" &&
                                    Array.isArray(kvs) &&
                                    (srcKV = kvs.filter(x => x.name === attrName)[0])) {
                                    if (srcKV.value.startsWith("/")) {
                                        return false;
                                    }
                                }
                                return true;
                            }
                        },
                    ]
                }
            }
        }, {
            test: /\.less$/,
            use: ['style-loader', 'css-loader', 'less-loader']
        }, {
            test: /\.(jpg|jpeg|png|gif|svg|eot|svg|ttf|woff|woff2)$/,
            type: 'asset/resource',
            generator: {
                filename(a, b) {
                    // a.asdf => "src/common/images/logo.png"
                    return path.relative(path.join(__dirname, "src"), path.resolve(a.filename)).split(path.sep).join("/");
                }
            }
        }, {
            test: /\.m?js$/,
            exclude: /(node_modules|bower_components)/,
            use: {
                loader: "babel-loader",
                options: {
                    /**
                     *   第一种方式
                     *      如果独立使用，你可以使用下面的命令(其他的项目，单独转码使用)
                     *          yarn add @babel/core @babel/preset-env babel-loader core-js html-loader html-webpack-plugin regenerator-runtime webpack webpack-cli -D
                     */
                    presets: [
                        ["@babel/preset-env", {
                            modules: false,
                            useBuiltIns: "usage",
                            corejs: {
                                version: 3,
                                proposals: true,
                            },
                            targets: {
                                ie: 8
                            }
                        }]
                    ],
                    /**
                     *   第二种方式
                     *      如果独立使用，你可以使用下面的命令(其他的项目，单独转码使用)
                     *          yarn add @babel/core @babel/plugin-transform-runtime @babel/preset-env @babel/runtime @babel/runtime-corejs3 babel-loader html-loader html-webpack-plugin webpack webpack-cli -D
                     */
                    // presets: [
                    //     ["@babel/preset-env"]
                    // ],
                    // plugins: [
                    //     ['@babel/plugin-transform-runtime', {
                    //         corejs: {
                    //             version: 3,
                    //             proposals: true
                    //         },
                    //         useESModules: true
                    //     }]
                    // ]
                }
            }
        }]
    },
    resolve: {
        alias: {
            //  [Vue warn]: Component provided template option but runtime compilation is not supported in this build of Vue. Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js". 
            'vue': 'vue/dist/vue.esm-bundler.js'
        }
    },
    plugins: [
        //  Feature flags __VUE_OPTIONS_API__, __VUE_PROD_DEVTOOLS__ are not explicitly defined. You are running the esm-bundler build of Vue, which expects these compile-time feature flags to be globally injected via the bundler config in order to get better tree-shaking in the production bundle.
        new webpack.DefinePlugin({
            __VUE_OPTIONS_API__: true,
            __VUE_PROD_DEVTOOLS__: false,
        }),
        new VueLoaderPlugin()
    ]
};
multiPageConfig.forEach(singlePage => {
    let tempEntryObj = {};
    tempEntryObj[singlePage.entry.targetPath] = singlePage.entry.sourcePath;
    Object.assign(tempModuleExportsObj.entry, tempEntryObj);
    let tempHtmlWebPackOption = {
        inject: true,
        hash: true, //开启hash  ?[hash]
        chunks: [singlePage.entry.targetPath], //页面要引入的包
    };
    Object.assign(tempHtmlWebPackOption, {
        template: singlePage.htmlWebPack.sourcePath,
        filename: singlePage.htmlWebPack.targetPath
    });
    tempModuleExportsObj.plugins.push(new HtmlWebPack(tempHtmlWebPackOption));
});
module.exports = tempModuleExportsObj;