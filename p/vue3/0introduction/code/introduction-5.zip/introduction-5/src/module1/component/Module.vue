<template>
  <div class="module-comp-container">
    <p>单文件组件：这里展示一张图片</p>
    <img src="../images/module.png">
  </div>
</template>
<script>
export default {
  name: "Module",
};
</script>