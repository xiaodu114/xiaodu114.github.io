<template>
  <div
    class="display-text-container"
    :style="uStyle"
  >
    <span class="text">{{value}}</span>
  </div>
</template>
<script>
export default {
  name: "DisplayText",
  props: {
    value: {
      type: String,
      default() {
        return "你想写点什么……";
      },
    },
    uStyle: {
      type: Object,
    },
  },
};
</script>
<style lang="less">
.display-text-container {
  border: 1px solid #3cb878;
  padding: 15px;
  margin-bottom: 10px;
  > .text {
    font-size: 14px;
  }
}
</style>