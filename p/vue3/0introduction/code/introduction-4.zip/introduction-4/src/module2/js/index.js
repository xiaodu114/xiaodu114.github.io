import '../css/index.less';

import * as Vue from "vue";
import DisplayText from '../../common/component/DisplayText.vue';
import Module from '../component/Module.vue';
Vue.createApp({
    data() {
        return {
            msg: "Hi，这里是 Vue3 + webpack 多入口 示例项目 模块2 入口页面",
            displayText: "再说一遍，这里是 模块2 入口页面",
            displayTextStyle: {
                fontWeight: "bold"
            }
        }
    },
    components: {
        DisplayText,
        Module
    }
}).mount('#vue3Module2Entry');