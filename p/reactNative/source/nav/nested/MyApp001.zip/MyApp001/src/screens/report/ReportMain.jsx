import { View, Text, StyleSheet } from 'react-native';

export default function ReportMainScreen() {
  return (
    <View style={styles.container}>
      <Text>上报页面</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});