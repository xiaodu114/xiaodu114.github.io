import { View, Text, StyleSheet } from 'react-native';

export default function AddressBookScreen() {
  return (
    <View style={styles.container}>
      <Text>消息：通讯录</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});