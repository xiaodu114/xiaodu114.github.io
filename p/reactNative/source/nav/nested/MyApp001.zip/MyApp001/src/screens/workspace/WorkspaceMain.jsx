import { View, Text, StyleSheet } from 'react-native';

export default function WorkspaceMainScreen() {
  return (
    <View style={styles.container}>
      <Text>工作台</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});