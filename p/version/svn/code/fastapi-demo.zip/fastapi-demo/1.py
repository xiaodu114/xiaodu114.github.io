import os
import datetime
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/get_date_time", summary="获取服务器端日期时间")
def get_server_datetime():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

project_dir = os.path.dirname(os.path.abspath(__file__))
#   我去这个顺序这么重要吗？如果放在路由 /get_date_time 的上面，站点可以正常启动，但是访问时就报错了
app.mount("/",StaticFiles(directory=os.path.join(project_dir,"www"), html=True))

if __name__ == '__main__':
    #   http 启动
    # uvicorn.run(app, host="192.168.xxx.xxx", port=3000, workers=1)

    #   https 启动
    # key_file = "/home/xxx/3-soft/zheshu/*.key"
    # cert_file = "/home/xxx/3-soft/zheshu/*.crt"
    # uvicorn.run(app, host="192.168.xxx.xxx", port=3000, workers=1, ssl_keyfile=key_file, ssl_certfile=cert_file)

    key_file = "/home/xxx/3-soft/zheshu/*.key"
    cert_file = "/home/xxx/3-soft/zheshu/*.pem"
    uvicorn.run(app, host="192.168.xxx.xxx", port=3000, workers=1, ssl_keyfile=key_file, ssl_certfile=cert_file)