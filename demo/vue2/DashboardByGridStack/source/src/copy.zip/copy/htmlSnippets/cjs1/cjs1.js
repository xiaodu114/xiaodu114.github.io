﻿module.exports.data = {
    title: "模块规范：CommonJS",
    detail: "我是一个独立的无依赖的模块",
    preText:
`module.exports.data = {
    title: "模块规范：CommonJS",
    detail: "我是一个独立的无依赖的模块",
    preText:""
}
`
}