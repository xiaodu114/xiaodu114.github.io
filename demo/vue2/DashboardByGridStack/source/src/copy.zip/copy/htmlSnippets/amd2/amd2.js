﻿define(function () {
    return {
        data: {
            title: "模块规范：AMD",
            detail: "我是一个独立的无依赖的模块，写法2",
            preText: 
`define(function () {
    return {
        data: {
            title: "模块规范：AMD",
            detail: "我是一个独立的无依赖的模块，写法2",
            preText:""
        }
    }
});
`
        }
    }
});