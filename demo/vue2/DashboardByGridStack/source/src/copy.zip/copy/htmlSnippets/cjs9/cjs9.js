﻿var ddztestlib01 = require('./ddztestlib01.js');
module.exports = {
    data: {
        title: "我是CJS9，我会使用一个已经打包好的vue组件库，类似已CDN的方式使用element-ui，注意如果window.Vue存在则全局注册组件，请留心组件名称的问题",
        ddzcomponent01prop1: "给我组件1的属性1赋值",
        ddzcomponent02prop1: "给我组件2的属性1赋值",
        preText: `var ddztestlib01 = require('./ddztestlib01.js');
module.exports = {
    data: {
        title: "我是CJS9，我会使用一个已经打包好的vue组件库，类似已CDN的方式使用element-ui，注意如果window.Vue存在则全局注册组件，请留心组件名称的问题",
        ddzcomponent01prop1: "给我组件1的属性1赋值",
        ddzcomponent02prop1: "给我组件2的属性1赋值",
        preText:""
    },
    methods: {}
} 
`
    },
    methods: {}
}