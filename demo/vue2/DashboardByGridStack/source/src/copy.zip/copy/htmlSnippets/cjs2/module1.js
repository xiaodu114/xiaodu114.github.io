﻿exports.data1 = "你好，我是CommonJS模块1中的数据1";
exports.fn1 = function () {
    alert("你好，我是CommonJS模块1中的方法1");
}
